# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What This Is

An interactive web-based canal route planner for Amsterdam. Users click points on a map; the app snaps them to the nearest canal and finds the shortest path using Dijkstra's algorithm. Travel time is calculated per-segment using speed properties on each canal feature.

## Running the App

```bash
cd grachtensite
python3 server.py
# Open http://localhost:8000
```

The server is a minimal Python HTTP server (`server.py`) that adds CORS headers so the frontend can fetch local GeoJSON files. No build step required.

## Data Setup

The frontend reads two GeoJSON files from `grachtensite/data/`:
- `Amsterdamcanals.geojson` — canal network with `speed_kmh` and `oneway` properties
- `rondvaartopenafstapplekken.geojson` — docking/boarding locations

If those files need to be regenerated:
```bash
cd grachtensite
python3 filter_canals.py          # filters raw OSM data to Amsterdam bounding box
python3 update_amstel_speed.py    # patches speed_kmh on Amstel canal segments
python3 create_routing_graph.py   # builds a NetworkX graph (used for testing; output not consumed by frontend)
```

Python dependencies: `shapely`, `networkx`, `geopandas`, `fuzzywuzzy`.

## Architecture

All routing logic lives in the browser (`grachtensite/script.js`, ~500 lines). There is no API server.

**Startup flow:**
1. `initLeafletMap()` initialises the Leaflet map and wires up click handlers.
2. `loadGeoJSONData()` fetches both GeoJSON files, then calls:
   - `buildCanalGraph()` — converts GeoJSON LineStrings into an in-memory graph: `{ nodes: [{lat, lng}], edges: [{from, to, distance, segment, speed_kmh}] }`
   - `loadDockingLocations()` — adds dock markers to the map.

**User interaction → route:**
1. Map click → `snapToNearestCanal()` → marker placed on the nearest canal node.
2. When ≥2 points exist → `dijkstraShortestPath()` over the in-memory graph.
3. `drawRoute()` renders a red polyline; `updateRouteInfo()` populates the sidebar with distance and `distance / speed * 60` travel time.

One-way constraints come from the `oneway` property on GeoJSON features; variable speeds come from `speed_kmh`. Multi-stop routes concatenate shortest-path segments between consecutive waypoints.

**MapLibre GL JS** is loaded via CDN but not wired up — there is a placeholder `initMapLibreMap()` function if a vector-tile layer is ever needed.
