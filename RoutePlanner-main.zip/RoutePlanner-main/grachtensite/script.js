// Map configuration
const AMSTERDAM_COORDS = [52.3676, 4.9041]; // Amsterdam coordinates
const ZOOM_LEVEL = 13;
const GPS_ENABLED = true; // set to false to disable GPS feature entirely
const OFF_ROUTE_THRESHOLD_M = 50; // meters off-route before stopping remaining-time calculation

// Initialize maps when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Leaflet map
    initLeafletMap();
    
    // Initialize MapLibre map
    initMapLibreMap();
});

// Global variable to store canal segments for snapping
let canalSegments = [];

// GPS navigation state
let currentRoutePath = [];
let currentRouteTotal = { time: 0, distance: 0 };
let gpsWatchId = null;
let gpsMarker = null;
let gpsActive = false;
let drivenLine = null;

// Graph structure for routing
let canalGraph = {
    nodes: [], // Array of {lat, lng}
    edges: [] // Array of {from: nodeIdx, to: nodeIdx, time: minutes, segment: [[lat, lng], [lat, lng]], speed_kmh}
};

// Helper: Find or add a node and return its index
function getNodeIndex(nodes, lat, lng) {
    for (let i = 0; i < nodes.length; i++) {
        if (Math.abs(nodes[i].lat - lat) < 1e-7 && Math.abs(nodes[i].lng - lng) < 1e-7) {
            return i;
        }
    }
    nodes.push({lat, lng});
    return nodes.length - 1;
}

// Build the canal graph from canalSegments and feature properties
function buildCanalGraph(features) {
    const nodes = [];
    const edges = [];
    features.forEach(feature => {
        const geometry = feature.geometry;
        const properties = feature.properties;
        let speed = properties.speed_kmh ? Number(properties.speed_kmh) : 6; // Default 6 km/h if missing
        // Robust oneway check
        let isBidirectional = true;
        if (typeof properties.oneway !== 'undefined') {
            isBidirectional = String(properties.oneway).toLowerCase() === 'no';
        }
        if (geometry.type === 'MultiLineString') {
            geometry.coordinates.forEach(lineString => {
                for (let i = 0; i < lineString.length - 1; i++) {
                    // [lng, lat] to [lat, lng]
                    const a = {lat: lineString[i][1], lng: lineString[i][0]};
                    const b = {lat: lineString[i+1][1], lng: lineString[i+1][0]};
                    const idxA = getNodeIndex(nodes, a.lat, a.lng);
                    const idxB = getNodeIndex(nodes, b.lat, b.lng);
                    const dist = latLngDistance(a, b); // meters
                    edges.push({from: idxA, to: idxB, distance: dist, segment: [a, b], speed_kmh: speed});
                    if (isBidirectional) {
                        edges.push({from: idxB, to: idxA, distance: dist, segment: [b, a], speed_kmh: speed});
                    }
                }
            });
        }
    });
    canalGraph.nodes = nodes;
    canalGraph.edges = edges;
}

// Find the closest node in the graph to a given latlng
function findClosestNode(latlng) {
    let minDist = Infinity;
    let idx = -1;
    canalGraph.nodes.forEach((node, i) => {
        const d = latLngDistance(latlng, node);
        if (d < minDist) {
            minDist = d;
            idx = i;
        }
    });
    return idx;
}

// Helper: Calculate distance between two lat/lng points (Haversine formula)
function latLngDistance(a, b) {
    const toRad = x => x * Math.PI / 180;
    const R = 6371000; // meters
    const dLat = toRad(b.lat - a.lat);
    const dLng = toRad(b.lng - a.lng);
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const aVal = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.sin(dLng/2) * Math.sin(dLng/2) * Math.cos(lat1) * Math.cos(lat2);
    const c = 2 * Math.atan2(Math.sqrt(aVal), Math.sqrt(1-aVal));
    return R * c;
}

// Helper: Find closest point on a line segment to a given point
function closestPointOnSegment(p, a, b) {
    // p, a, b: {lat, lng}
    const toXY = (latlng) => {
        // Approximate conversion for small distances
        return [latlng.lng, latlng.lat];
    };
    const [x, y] = toXY(p);
    const [x1, y1] = toXY(a);
    const [x2, y2] = toXY(b);
    const dx = x2 - x1;
    const dy = y2 - y1;
    if (dx === 0 && dy === 0) return a;
    const t = ((x - x1) * dx + (y - y1) * dy) / (dx*dx + dy*dy);
    if (t <= 0) return a;
    if (t >= 1) return b;
    return {lat: y1 + t * dy, lng: x1 + t * dx};
}

// Find the nearest point on any canal segment to a given latlng
function snapToNearestCanal(latlng) {
    let minDist = Infinity;
    let snapped = latlng;
    canalSegments.forEach(seg => {
        for (let i = 0; i < seg.length - 1; i++) {
            const a = {lat: seg[i][0], lng: seg[i][1]};
            const b = {lat: seg[i+1][0], lng: seg[i+1][1]};
            const pt = closestPointOnSegment(latlng, a, b);
            const dist = latLngDistance(latlng, pt);
            if (dist < minDist) {
                minDist = dist;
                snapped = pt;
            }
        }
    });
    return snapped;
}

// Dijkstra's algorithm for shortest path by distance
function dijkstraShortestPath(startIdx, endIdx) {
    const numNodes = canalGraph.nodes.length;
    const dists = Array(numNodes).fill(Infinity);
    const prev = Array(numNodes).fill(null);
    const visited = Array(numNodes).fill(false);
    dists[startIdx] = 0;
    for (let i = 0; i < numNodes; i++) {
        // Find unvisited node with smallest distance
        let u = -1;
        let minDist = Infinity;
        for (let j = 0; j < numNodes; j++) {
            if (!visited[j] && dists[j] < minDist) {
                minDist = dists[j];
                u = j;
            }
        }
        if (u === -1) break;
        if (u === endIdx) break;
        visited[u] = true;
        // For each neighbor
        canalGraph.edges.forEach(edge => {
            if (edge.from === u) {
                const v = edge.to;
                if (visited[v]) return;
                const alt = dists[u] + edge.distance;
                if (alt < dists[v]) {
                    dists[v] = alt;
                    prev[v] = {from: u, edge: edge};
                }
            }
        });
    }
    // Reconstruct path
    let path = [];
    let node = endIdx;
    let totalDistance = dists[endIdx];
    if (!isFinite(totalDistance)) return {path: [], totalDistance: Infinity, totalTime: 0};
    let totalTime = 0;
    while (node !== null && prev[node]) {
        path.unshift(prev[node].edge);
        // Add segment time (distance / speed)
        const seg = prev[node].edge.segment;
        const segDist = prev[node].edge.distance;
        const segSpeed = prev[node].edge.speed_kmh || 6;
        totalTime += (segDist / 1000) / segSpeed * 60; // minutes
        node = prev[node].from;
    }
    totalDistance = totalDistance / 1000; // meters to km
    return {path, totalDistance, totalTime};
}

// Draw the route on the map
let routeLine = null;
function drawRoute(map, path) {
    if (routeLine) {
        map.removeLayer(routeLine);
    }
    const latlngs = [];
    path.forEach(edge => {
        latlngs.push([edge.segment[0].lat, edge.segment[0].lng]);
    });
    if (path.length > 0) {
        // Add the last point
        latlngs.push([path[path.length-1].segment[1].lat, path[path.length-1].segment[1].lng]);
    }
    routeLine = L.polyline(latlngs, {color: 'red', weight: 5, opacity: 0.9}).addTo(map);
}

// Leaflet Map Implementation
function initLeafletMap() {
    // Create Leaflet map
    const leafletMap = L.map('map').setView(AMSTERDAM_COORDS, ZOOM_LEVEL);
    
    // Add OpenStreetMap tiles
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager_nolabels/{z}/{x}/{y}{r}.png', {
        attribution: '© OpenStreetMap contributors © CARTO',
        maxZoom: 19
    }).addTo(leafletMap);
    
    // Load and display GeoJSON data
    loadGeoJSONData(leafletMap);

    // --- Add multi-point route logic ---
    let selectedPoints = [];
    const markerLayer = L.layerGroup().addTo(leafletMap);
    // Custom icon for route planning points
    const routePointIcon = L.icon({
        iconUrl: 'boat.png',
        iconSize: [44, 44],
        iconAnchor: [22, 44],
        popupAnchor: [0, -36]
    });
    // Draw the full route through all points
    function drawFullRoute() {
        if (selectedPoints.length < 2) {
            if (routeLine) {
                leafletMap.removeLayer(routeLine);
                routeLine = null;
            }
            currentRoutePath = [];
            currentRouteTotal = { time: 0, distance: 0 };
            updateRouteInfo(0, 0, []);
            return;
        }
        let fullPath = [];
        let totalDistance = 0;
        let totalTime = 0;
        let segments = [];
        for (let i = 0; i < selectedPoints.length - 1; i++) {
            const startIdx = findClosestNode(selectedPoints[i]);
            const endIdx = findClosestNode(selectedPoints[i+1]);
            const {path, totalDistance: segDist, totalTime: segTime} = dijkstraShortestPath(startIdx, endIdx);
            if (path.length === 0) {
                updateRouteInfo(0, 0, []);
                alert('No route found between some selected points.');
                return;
            }
            fullPath = fullPath.concat(path);
            totalDistance += segDist;
            totalTime += segTime;
            segments.push({time: segTime, distance: segDist});
        }
        currentRoutePath = fullPath;
        currentRouteTotal = { time: totalTime, distance: totalDistance };
        drawRoute(leafletMap, fullPath);
        updateRouteInfo(totalTime, totalDistance, segments);
    }
    leafletMap.on('click', function(e) {
        // Add a new point
        const snappedLatLng = snapToNearestCanal(e.latlng);
        selectedPoints.push(snappedLatLng);
        const marker = L.marker(snappedLatLng, { icon: routePointIcon }).addTo(markerLayer);
        marker.bindPopup(`Point ${selectedPoints.length}`).openPopup();
        drawFullRoute();
    });
    // Reset button logic
    const resetBtn = document.getElementById('reset-route-btn');
    if (resetBtn) {
        resetBtn.addEventListener('click', function() {
            selectedPoints = [];
            markerLayer.clearLayers();
            if (routeLine) {
                leafletMap.removeLayer(routeLine);
                routeLine = null;
            }
            currentRoutePath = [];
            currentRouteTotal = { time: 0, distance: 0 };
            if (GPS_ENABLED) stopGPS(leafletMap);
            clearRouteInfo();
        });
    }
    // Undo button logic
    const undoBtn = document.getElementById('undo-route-btn');
    if (undoBtn) {
        undoBtn.addEventListener('click', function() {
            if (selectedPoints.length > 0) {
                selectedPoints.pop();
                markerLayer.clearLayers();
                // Redraw all markers with custom icon
                selectedPoints.forEach((pt, idx) => {
                    const marker = L.marker(pt, { icon: routePointIcon }).addTo(markerLayer);
                    marker.bindPopup(`Point ${idx+1}`).openPopup();
                });
                drawFullRoute();
            }
        });
    }
    // --- End multi-point route logic ---

    if (GPS_ENABLED) initGPS(leafletMap);

    console.log('Leaflet map initialized');
}

// Load and display GeoJSON data
function loadGeoJSONData(map) {
    console.log('Attempting to load GeoJSON data...');
    
    // Create layer groups for different data types
    const dockingLayer = L.layerGroup();
    const routesLayer = L.layerGroup();
    
    // Do NOT add layers to map by default
    // dockingLayer.addTo(map);
    // routesLayer.addTo(map);
    
    // Create layer control (legend) with both overlays
    const overlays = {
        "Docking Locations": dockingLayer,
        "Amsterdam Canals": routesLayer
    };
    
    // Always show the legend expanded
    L.control.layers(null, overlays, { collapsed: false }).addTo(map);
    
    // Load docking locations
    loadDockingLocations(map, dockingLayer);
    
    // Load canal routes
    loadCanalRoutes(map, routesLayer);
}

// Load docking locations
function loadDockingLocations(map, layer) {
    // Define custom icon for docking stations
    const dockingIcon = L.icon({
        iconUrl: 'symbol.png',
        iconSize: [40, 40], // width, height in pixels
        iconAnchor: [20, 40], // point of the icon which will correspond to marker's location
        popupAnchor: [0, -36] // point from which the popup should open relative to the iconAnchor
    });
    fetch('data/rondvaartopenafstapplekken.geojson')
        .then(response => {
            console.log('Docking locations response status:', response.status);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('Docking locations loaded successfully:', data);
            console.log('Number of docking locations:', data.features.length);
            // Process each feature in the GeoJSON
            data.features.forEach((feature, index) => {
                const coords = feature.geometry.coordinates;
                const properties = feature.properties;
                console.log(`Processing docking location ${index + 1}:`, properties.Name, 'at', coords);
                // Create marker with custom icon
                const marker = L.marker([coords[1], coords[0]], { icon: dockingIcon }).addTo(layer);
                // Create popup content
                let popupContent = `<b>${properties.Name}</b>`;
                if (properties.description) {
                    // Clean up the description (remove HTML tags for safety)
                    const cleanDescription = properties.description
                        .replace(/<img[^>]*>/g, '') // Remove images
                        .replace(/<br\s*\/?/g, '<br>') // Keep line breaks
                        .replace(/<[^>]*>/g, ''); // Remove other HTML tags
                    popupContent += `<br><br>${cleanDescription}`;
                }
                marker.bindPopup(popupContent);
            });
            console.log(`Successfully loaded ${data.features.length} docking locations`);
        })
        .catch(error => {
            console.error('Error loading docking locations:', error);
        });
}

// Update loadCanalRoutes to store canal segments
function loadCanalRoutes(map, layer) {
    fetch('data/Amsterdamcanals.geojson')
        .then(response => {
            console.log('Amsterdam canal routes response status:', response.status);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('Amsterdam canal routes loaded successfully:', data);
            console.log('Number of Amsterdam canal routes:', data.features.length);
            // Store all canal segments for snapping
            canalSegments = [];
            // Build the canal graph for routing
            buildCanalGraph(data.features);
            // Process each canal route
            data.features.forEach((feature, index) => {
                const geometry = feature.geometry;
                if (geometry.type === 'MultiLineString') {
                    geometry.coordinates.forEach(lineString => {
                        // Convert coordinates from [lng, lat] to [lat, lng] for Leaflet
                        const latLngs = lineString.map(coord => [coord[1], coord[0]]);
                        canalSegments.push(latLngs);
                        // Create polyline for the canal route
                        const polyline = L.polyline(latLngs, {
                            color: '#0066cc',
                            weight: 3,
                            opacity: 0.8
                        }).addTo(layer);
                        
                        // Add popup with canal information
                        let popupContent = `<b>Amsterdam Canal</b>`;
                        const properties = feature.properties;
                        if (properties.name) {
                            popupContent = `<b>${properties.name}</b>`;
                        }
                        if (properties.fclass) {
                            popupContent += `<br>Type: ${properties.fclass}`;
                        }
                        if (properties.speed_kmh) {
                            popupContent += `<br>Speed limit: ${properties.speed_kmh} km/h`;
                        }
                        if (properties.oneway) {
                            popupContent += `<br>One-way: ${properties.oneway}`;
                        }
                        
                        polyline.bindPopup(popupContent);
                    });
                }
            });
            
            console.log(`Successfully loaded ${data.features.length} Amsterdam canal routes`);
        })
        .catch(error => {
            console.error('Error loading Amsterdam canal routes:', error);
        });
}

// Fallback markers if GeoJSON fails to load
function addFallbackMarkers(map) {
    // Just show a simple message if GeoJSON fails to load
    console.log('GeoJSON data could not be loaded');
}

// MapLibre Map Implementation
function initMapLibreMap() {
    // Note: MapLibre requires a different container, so we'll create a separate implementation
    // For now, we'll focus on Leaflet as the primary map
    
    // If you want to use MapLibre instead, you would use code like this:
    /*
    const mapLibreMap = new maplibregl.Map({
        container: 'map',
        style: {
            version: 8,
            sources: {
                'osm': {
                    type: 'raster',
                    tiles: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],
                    tileSize: 256,
                    attribution: '© OpenStreetMap contributors'
                }
            },
            layers: [{
                id: 'osm',
                type: 'raster',
                source: 'osm',
                minzoom: 0,
                maxzoom: 22
            }]
        },
        center: AMSTERDAM_COORDS,
        zoom: ZOOM_LEVEL
    });
    */
    
    console.log('MapLibre map ready for implementation');
}

// Utility function to add custom markers
function addCustomMarker(map, coordinates, popupContent) {
    if (map instanceof L.Map) {
        // Leaflet marker
        const marker = L.marker(coordinates).addTo(map);
        if (popupContent) {
            marker.bindPopup(popupContent);
        }
        return marker;
    }
    // Add MapLibre marker implementation here if needed
}

// Export functions for potential use in other scripts
window.MapUtils = {
    addCustomMarker,
    AMSTERDAM_COORDS,
    ZOOM_LEVEL
}; 

function getRemainingFromPosition(latlng) {
    if (currentRoutePath.length === 0) return { offRoute: true };
    let bestDist = Infinity, bestEdgeIdx = -1, bestT = 0;
    currentRoutePath.forEach((edge, i) => {
        const a = edge.segment[0], b = edge.segment[1];
        const dx = b.lng - a.lng, dy = b.lat - a.lat;
        let t = 0;
        if (dx !== 0 || dy !== 0) {
            t = ((latlng.lng - a.lng) * dx + (latlng.lat - a.lat) * dy) / (dx*dx + dy*dy);
            t = Math.max(0, Math.min(1, t));
        }
        const pt = { lat: a.lat + t * dy, lng: a.lng + t * dx };
        const d = latLngDistance(latlng, pt);
        if (d < bestDist) { bestDist = d; bestEdgeIdx = i; bestT = t; }
    });
    if (bestDist > OFF_ROUTE_THRESHOLD_M) return { offRoute: true };
    const bestEdge = currentRoutePath[bestEdgeIdx];
    let remainingDistance = (1 - bestT) * bestEdge.distance;
    let remainingTime = (remainingDistance / 1000) / (bestEdge.speed_kmh || 6) * 60;
    for (let j = bestEdgeIdx + 1; j < currentRoutePath.length; j++) {
        const e = currentRoutePath[j];
        remainingDistance += e.distance;
        remainingTime += (e.distance / 1000) / (e.speed_kmh || 6) * 60;
    }
    return { offRoute: false, remainingDistance: remainingDistance / 1000, remainingTime, bestEdgeIdx, bestT };
}

function stopGPS(map) {
    if (gpsWatchId !== null) { navigator.geolocation.clearWatch(gpsWatchId); gpsWatchId = null; }
    if (gpsMarker) { map.removeLayer(gpsMarker); gpsMarker = null; }
    if (drivenLine) { map.removeLayer(drivenLine); drivenLine = null; }
    gpsActive = false;
    const btn = document.getElementById('gps-btn');
    if (btn) btn.classList.remove('gps-active');
    if (currentRoutePath.length > 0) {
        const infoDiv = document.getElementById('route-info');
        if (infoDiv) {
            infoDiv.textContent = `${Math.round(currentRouteTotal.time)} min  ·  ${currentRouteTotal.distance.toFixed(1)} km`;
            infoDiv.classList.add('visible');
        }
    }
}

function initGPS(map) {
    const btn = document.getElementById('gps-btn');
    if (!btn) return;
    btn.addEventListener('click', function() {
        if (gpsActive) {
            stopGPS(map);
            return;
        }
        if (currentRoutePath.length === 0) { alert('Plan a route first.'); return; }
        if (!navigator.geolocation) { alert('GPS not supported by your browser.'); return; }
        gpsActive = true;
        btn.classList.add('gps-active');
        gpsWatchId = navigator.geolocation.watchPosition(
            function(position) {
                const latlng = { lat: position.coords.latitude, lng: position.coords.longitude };
                // Move / create blue GPS dot
                if (gpsMarker) {
                    gpsMarker.setLatLng([latlng.lat, latlng.lng]);
                } else {
                    gpsMarker = L.circleMarker([latlng.lat, latlng.lng], {
                        radius: 10, color: '#1565C0', fillColor: '#42A5F5', fillOpacity: 0.9, weight: 2
                    }).addTo(map);
                }
                // Follow user at street-level zoom
                map.setView([latlng.lat, latlng.lng], 17, { animate: true, duration: 0.5 });
                // Remaining calculation
                const result = getRemainingFromPosition(latlng);
                const infoDiv = document.getElementById('route-info');
                if (result.offRoute) {
                    if (drivenLine) { map.removeLayer(drivenLine); drivenLine = null; }
                    if (infoDiv) { infoDiv.textContent = 'Off route'; infoDiv.classList.add('visible'); }
                    return;
                }
                // Build driven (green) polyline up to current position
                const drivenLatLngs = [];
                for (let i = 0; i < result.bestEdgeIdx; i++) {
                    if (drivenLatLngs.length === 0) drivenLatLngs.push([currentRoutePath[i].segment[0].lat, currentRoutePath[i].segment[0].lng]);
                    drivenLatLngs.push([currentRoutePath[i].segment[1].lat, currentRoutePath[i].segment[1].lng]);
                }
                const edge = currentRoutePath[result.bestEdgeIdx];
                if (drivenLatLngs.length === 0) drivenLatLngs.push([edge.segment[0].lat, edge.segment[0].lng]);
                drivenLatLngs.push([
                    edge.segment[0].lat + result.bestT * (edge.segment[1].lat - edge.segment[0].lat),
                    edge.segment[0].lng + result.bestT * (edge.segment[1].lng - edge.segment[0].lng)
                ]);
                if (drivenLatLngs.length > 1) {
                    if (drivenLine) { drivenLine.setLatLngs(drivenLatLngs); }
                    else { drivenLine = L.polyline(drivenLatLngs, { color: '#2e7d32', weight: 5, opacity: 0.9 }).addTo(map); }
                }
                // Update pill
                if (infoDiv) {
                    infoDiv.textContent = result.remainingDistance < 0.05
                        ? 'Arrived'
                        : `${Math.round(result.remainingTime)} min remaining  ·  ${result.remainingDistance.toFixed(1)} km`;
                    infoDiv.classList.add('visible');
                }
            },
            function(error) { console.warn('GPS error:', error); },
            { enableHighAccuracy: true, maximumAge: 1000 }
        );
    });
}

function updateRouteInfo(totalTime, totalDistance, segments = []) {
    const infoDiv = document.getElementById('route-info');
    if (!infoDiv) return;
    if (segments.length > 0) {
        infoDiv.textContent = `${Math.round(totalTime)} min  ·  ${totalDistance.toFixed(1)} km`;
        infoDiv.classList.add('visible');
    } else {
        infoDiv.classList.remove('visible');
    }
}
function clearRouteInfo() {
    const infoDiv = document.getElementById('route-info');
    if (!infoDiv) return;
    infoDiv.textContent = '';
    infoDiv.classList.remove('visible');
} 